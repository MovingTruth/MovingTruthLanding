# Personal Reflection

Tonight we made a conscious decision to stop engineering and begin understanding.

What started as simple improvements led to an image.

The image led to Artifacts.

Artifacts led to a Museum.

The Museum led to a movement.

We decided to build the foundation first.

One stone at a time.

Purpose before progress.
