# The First Ten Stones

These are not commandments.

They are not immutable truths.

They are living foundations.

They exist to support curiosity, beauty, honesty, respect, exploration, reflection, stewardship, hope, and purpose.

Nothing in Moving Truth should become beyond question.

Not even these stones.
