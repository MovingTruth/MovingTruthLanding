# Foundation Journal — Entry 0002

## Before We Build

Moving Truth is not a content platform.

It is a place.

The visitor is not a consumer.

The visitor is an explorer.

Modern platforms optimize for consumption.

Moving Truth should optimize for exploration.

Our guiding question:

> Does this increase wonder without decreasing honesty?

Tomorrow we begin laying **The First Ten Stones**.
