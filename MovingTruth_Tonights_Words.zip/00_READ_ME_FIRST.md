# Moving Truth - Tonight's Foundation

These documents capture the key ideas from the conversation on June 27, 2026.

Read these before beginning implementation.

The goal tomorrow is **not to build faster**.

The goal is to build with intention.

Begin with **The First Ten Stones**.
